/** Automatically generated file. DO NOT MODIFY */
package com.example.ncamm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}